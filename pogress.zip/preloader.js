var loader = document.getElementById("preeloader");
window.addEventListener("load", function(){
    loader.style.display = "none";
})